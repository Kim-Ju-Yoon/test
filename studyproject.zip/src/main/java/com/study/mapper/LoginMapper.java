package com.study.mapper;

import com.study.model.LoginVO;

public interface LoginMapper {
	public void memreg(LoginVO member);

}
